const { creercategories } = require('../controllers/utilisateurs.controller');

describe('Test de la fonction creercategories', () => {
    beforeEach(() => {
        jest.clearAllMocks();
    });

    test('Création de nouvelle catégorie avec des données valides', async () => {
        const req = {
            body: {
                DESC_TYPE: ''
                // Ajoutez d'autres champs si nécessaire pour la création de lop catégorieoknnppnn
            }
        };
        const res = {
            status: jest.fn().mockReturnThis(),
            json: jest.fn()
        };

        await creercategories(req, res);

        expect(res.status).toHaveBeenCalledWith(200);
        expect(res.json).toHaveBeenCalledWith({
            message: "Nouvelle catégorie créée avec succès",
            data: expect.any(Object) // Vous pouvez définir ici la structure de l'objet de catégorie attendu
        });
    });

    test('Création de nouvelle catégorie avec des données invalides', async () => {
        const req = {
            body: {
                DESC_TYPE: ''
                // Autres champs invalides si nécessaire
            }
        };
        const res = {
            status: jest.fn().mockReturnThis(),
            json: jest.fn()
        };

        await creercategories(req, res);

        expect(res.status).toHaveBeenCalledWith(422);
        expect(res.json).toHaveBeenCalledWith({
            message: "La validation des données a échoué",
            data: expect.any(Object) // Vous pouvez définir ici la structure des erreurs de validation attendues
        });
    });
});